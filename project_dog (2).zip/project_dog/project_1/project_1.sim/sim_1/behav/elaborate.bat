@echo off
set xv_path=C:\\Xilinx\\Vivado\\2016.3\\bin
call %xv_path%/xelab  -wto 616b89d3a88d4be38703261f984d5cbc -m64 --debug typical --relax --mt 2 -L xil_defaultlib -L secureip --snapshot game_behav xil_defaultlib.game -log elaborate.log
if "%errorlevel%"=="0" goto SUCCESS
if "%errorlevel%"=="1" goto END
:END
exit 1
:SUCCESS
exit 0
