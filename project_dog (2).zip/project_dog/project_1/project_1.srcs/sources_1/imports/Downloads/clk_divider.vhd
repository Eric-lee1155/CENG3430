library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity clock_divider is
    generic (N: integer); 
    Port (
        clk : IN STD_LOGIC;
        clk_out : OUT STD_LOGIC
    );
end clock_divider;

architecture Behavioral of clock_divider is
    signal counter : integer := 0;
    signal sig : STD_LOGIC := '0';
begin
    clk_out <= sig;
    process(clk)
    begin
        if (rising_edge(clk)) then
            if(counter = N - 1) then
                sig <= NOT sig;
                counter <= 0;
            else
                counter <= counter + 1;
            end if;
        end if;
    end process;
end Behavioral;
