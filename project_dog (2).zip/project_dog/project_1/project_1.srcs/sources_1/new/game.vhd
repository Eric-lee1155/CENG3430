----------------------------------------------------------------------------------
-- Company: 
-- Engineer: 
-- 
-- Create Date: 2023/05/11 17:14:31
-- Design Name: 
-- Module Name: game - Behavioral
-- Project Name: 
-- Target Devices: 
-- Tool Versions: 
-- Description: 
-- 
-- Dependencies: 
-- 
-- Revision:
-- Revision 0.01 - File Created
-- Additional Comments:
-- 
----------------------------------------------------------------------------------


library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

-- Uncomment the following library declaration if using
-- arithmetic functions with Signed or Unsigned values
use IEEE.NUMERIC_STD.ALL;

-- Uncomment the following library declaration if instantiating
-- any Xilinx leaf cells in this code.
--library UNISIM;
--use UNISIM.VComponents.all;

entity game is
    Port ( btnu : in STD_LOGIC;
           btnd : in STD_LOGIC;
           btnl : in STD_LOGIC;
           btnr : in STD_LOGIC;
           led : out STD_LOGIC_VECTOR (7 downto 0);
           CLK : in STD_LOGIC;
           sel:    buffer STD_LOGIC := '0';
           ssd:    out STD_LOGIC_VECTOR(6 downto 0);
           pmodled : out STD_LOGIC_VECTOR(15 downto 0);
           btn : in STD_LOGIC_VECTOR(3 downto 0)
--           ;    
           -- TODO-10: Fill in the input/output ports for Pmod ALS
--           cs  :buffer STD_LOGIC_VECTOR(0 downto 0);
--           miso    :in STD_LOGIC;
--           sclk    :buffer STD_LOGIC
           );
end game;

architecture Behavioral of game is

signal IsEnd: STD_LOGIC := '1';
signal clk_1hz : STD_LOGIC;
signal clk_4hz : STD_LOGIC;
component clock_divider_1hz is
port(
    CLK_IN: IN STD_LOGIC;
    CLK_OUT: OUT STD_LOGIC
);
end component;
component clock_divider_4hz is
port(
    CLK_IN: IN STD_LOGIC;
    CLK_OUT: OUT STD_LOGIC
);
end component;
signal game_time : INTEGER := 70 ; --count down
--signal temperiod : REAL;
signal assign_period : INTEGER  := 0;
--signal mark : INTEGER range 0 to 255 := 0;
signal mark : INTEGER := 10;
signal random_D : INTEGER := 0 ;
signal tembutton : STD_LOGIC_VECTOR (3 downto 0) := "0000";
signal dog_assign_state : STD_LOGIC_VECTOR (3 downto 0) := "0000";
signal mark_detect : STD_LOGIC_VECTOR (3 downto 0) := "0000";
signal isPositive : STD_LOGIC_VECTOR (3 downto 0) := "0000";
signal temled : STD_LOGIC_VECTOR (7 downto 0) := "00000000";
signal temmark_detect : STD_LOGIC := '0';
signal temisPositive : STD_LOGIC := '0';
signal finmark : INTEGER := 0;

component dog is
port(
assign_state : in STD_LOGIC;
button : in STD_LOGIC;
led : out STD_LOGIC;
clk_1hz : in STD_LOGIC;
clk_4hz : in STD_LOGIC;
mark_detect : out STD_LOGIC;
isPositive : out STD_LOGIC
);
end component;

component ssd_ctrl is 
        port (
            clk:    in  STD_LOGIC;
            data_in:in  STD_LOGIC_VECTOR(7 downto 0);
            sel:    buffer STD_LOGIC := '0';
            ssd:    out STD_LOGIC_VECTOR(6 downto 0)    
        );
end component;

signal rx_data : STD_LOGIC_VECTOR(14 downto 0);
signal data_in:  STD_LOGIC_VECTOR(7 downto 0);

begin
    
    CD_1Hz: clock_divider_1hz
        port map(CLK, clk_1hz);
        
    CD_4Hz: clock_divider_4hz
        port map(CLK, clk_4hz);

    DOG_0 : dog
        port map(dog_assign_state(0),tembutton(0),temled(0),clk_1hz,clk_4hz,mark_detect(0),isPositive(0));
        
    DOG_1 : dog
        port map(dog_assign_state(1),tembutton(1),temled(1),clk_1hz,clk_4hz,mark_detect(1),isPositive(1));
        
    DOG_2 : dog
        port map(dog_assign_state(2),tembutton(2),temled(2),clk_1hz,clk_4hz,mark_detect(2),isPositive(2));
        
    DOG_3 : dog
        port map(dog_assign_state(3),tembutton(3),temled(3),clk_1hz,clk_4hz,mark_detect(3),isPositive(3));
        
        
    process(clk_1hz,IsEnd) --game process/flow
    begin
    --running game        
        if rising_edge(clk_1hz) then -- count time
            if IsEnd = '0' then            
                game_time <= game_time - 1;
                temled(4) <= '0';
            else --game start
                game_time <= 70;
                temled(4) <= '1';
            end if;            
        end if;
    end process;
    
    process(clk_1hz,IsEnd) --game process/flow
    begin
    --running game        
        if rising_edge(clk_1hz) then -- count time        
            dog_assign_state <= "0000";
            if IsEnd = '0' then
                assign_period <= assign_period - 1;
                if (assign_period < 1 AND game_time > 8) then --assign which dog to active
                    random_D <= (game_time * 123 + 433) mod 4;
                    dog_assign_state(random_D) <= '1';
                    assign_period <= ((game_time * 123 + 433) mod 3) + 5 ;
                end if;
            end if;            
        end if;
    end process;
    
--    process(btnl,btnr,btnu,btnd,game_time)
    process(clk_4hz,game_time,mark,tembutton) --state transition
    begin        
        if rising_edge(clk_4hz) then
            if ((IsEnd = '1') AND (tembutton /= "0000")) then --game start
--                if rising_edge(clk_4hz) then
                IsEnd <= '0';
--                end if;
    
--            elsif rising_edge(clk_4hz) then
            elsif ((game_time < 1) OR (mark < 1)) then --game end/not
--                    finmark <= mark;
                    IsEnd <= '1';                    
                end if;
--            end if;
        end if;
    end process;
    
    process(temmark_detect,temisPositive,game_time,isEnd,clk_4hz) --mark_control
    begin
        if rising_edge(clk_4hz) then
            if isEnd = '0' AND game_time < 70 then
--            for i in 0 to 3 loop
--                if mark_detect(i) = '1' then
--                    if isPositive(i) = '0' then
--            if rising_edge(clk_4hz) then
                if (temmark_detect = '1' AND temisPositive = '1') then
                    mark <= mark + 1;
    --            elsif rising_edge(clk_4hz) then
                elsif (temmark_detect = '1' AND temisPositive = '0') then
                        mark <= mark - 1;
                end if;
                finmark <= mark;
--                    end if;
--            end if;
--            end loop;
--            temled(6)<='0';
--        elsif rising_edge(clk_4hz) then
            elsif isEnd = '1' then
                    mark <= 10;
--                temled(6)<='1';
            end if;
        end if;
    end process;
    
    temled(7)<= isEnd;
    led<=temled;
--    tembutton(0) <= btnu;
--    tembutton(1) <= btnd;
--    tembutton(3) <= btnr;
--    tembutton(2) <= btnl;

    tembutton(0) <= btn(0);
    tembutton(1) <= btn(1);
    tembutton(3) <= btn(3);
    tembutton(2) <= btn(2);

    
    temmark_detect <= '1' when (mark_detect(0) ='1' OR mark_detect(1) ='1' OR mark_detect(2) ='1' OR mark_detect(3) ='1') else '0';
    temisPositive <= '1' when (isPositive(0) ='1' OR isPositive(1) ='1' OR isPositive(2) ='1' OR isPositive(3) ='1') else '0';
    temled(5) <= temmark_detect;
    temled(6) <= temisPositive;
    
    pmodled(3 downto 0) <= "0101" when temled(0) = '1' else "0000";
    pmodled(7 downto 4) <= "0101" when temled(1) = '1' else "0000";
    pmodled(11 downto 8) <= "0101" when temled(2) = '1' else "0000";
    pmodled(15 downto 12) <= "0101" when temled(3) = '1' else "0000";
    
--    pmodled <= "1111111111111111";
--    isEnd <= '1';


u_ssd_ctrl : ssd_ctrl port map(CLK,data_in,sel,ssd);
data_in <= std_logic_vector(to_signed(mark,8)) when isEnd = '0' else std_logic_vector(to_signed(finmark,8)) ;
--data_in <= std_logic_vector(to_signed(game_time,8));
    
end Behavioral;
