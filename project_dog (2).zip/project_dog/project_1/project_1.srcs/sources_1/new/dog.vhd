----------------------------------------------------------------------------------
-- Company: 
-- Engineer: 
-- 
-- Create Date: 2023/05/11 17:14:31
-- Design Name: 
-- Module Name: dog - Behavioral
-- Project Name: 
-- Target Devices: 
-- Tool Versions: 
-- Description: 
-- 
-- Dependencies: 
-- 
-- Revision:
-- Revision 0.01 - File Created
-- Additional Comments:
-- 
----------------------------------------------------------------------------------


library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

-- Uncomment the following library declaration if using
-- arithmetic functions with Signed or Unsigned values
use IEEE.NUMERIC_STD.ALL;

-- Uncomment the following library declaration if instantiating
-- any Xilinx leaf cells in this code.
--library UNISIM;
--use UNISIM.VComponents.all;

entity dog is
  Port ( 
        assign_state : in STD_LOGIC;
        button : in STD_LOGIC;
        led : out STD_LOGIC;
        clk_1hz : in STD_LOGIC;
        clk_4hz : in STD_LOGIC;
        mark_detect : out STD_LOGIC; --change mark/not
--        active_change : out STD_LOGIC; --change state/not
        isPositive : out STD_LOGIC); -- mark ++/--

end dog;

architecture Behavioral of dog is
signal active_time : INTEGER range 0 to 5 := 5;
signal active_state : STD_LOGIC := '0';
signal temled : STD_LOGIC := '0';
signal temmark_detect :STD_LOGIC := '0';
signal temisPositive :STD_LOGIC := '0';
begin

    process(clk_1hz,active_state)
    begin
        if active_state = '1' then --time control
            if rising_edge(clk_1hz) then 
                active_time <= active_time - 1;
            end if;
        else
            active_time <= 4;
        end if;
    end process;
    
    process(button,active_state,clk_4hz)
    begin    
        if rising_edge(clk_4hz) then
            if button = '1' then
                if active_state = '1' then
                    temisPositive <= '1';
                else
                    temisPositive <= '0';
                end if;
    --        elsif rising_edge(clk_4hz) then
            else
--                if active_state = '0' then --state machine
                temisPositive <= '0';
--                end if;
            end if;
        end if;
    end process;
    
--    process(active_state)
--    begin
--        if active_state = '0' then --state machine
--            temled <= '0';
--        else
--            temled <= '1';
--        end if;
--    end process;
    temled <= active_state;
    
--    process(button)
--    begin    
----        if rising_edge(clk_4hz) then
--        if button = '1' then--state machine
--            temmark_detect <= '1';
--        else
--            temmark_detect <= '0';
--        end if;
----        end if;
--    end process;
    temmark_detect <= button when rising_edge(clk_4hz);
        
    process(active_time,temisPositive,assign_state,clk_4hz) -- state transition
    begin
    
        if rising_edge(clk_4hz) then --state control
            
--            if ((active_time < 1) OR (temisPositive = '1')) then
            if ((temisPositive = '1')) then
    --        if (active_time < 1) then
    --            if(rising_edge(clk_4hz)) then
                active_state <= '0';
    --            end if;
--        elsif(rising_edge(clk_4hz)) then
            else
                if assign_state = '1' then --activating
                    active_state <= '1';
                elsif (active_time < 1) then
                    active_state <= '0';
                end if;
            end if;
        end if;
    end process;
    
    led <= temled;
    mark_detect <= temmark_detect;
    isPositive <= temisPositive;
end Behavioral;
