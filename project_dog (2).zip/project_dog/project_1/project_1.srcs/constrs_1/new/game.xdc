
# Do not need to modify below
set_property PACKAGE_PIN Y9 [get_ports CLK];
set_property IOSTANDARD LVCMOS33 [get_ports CLK];
create_clock -period 10 [get_ports CLK];
#set_property CLOCK_DEDICATED_ROUTE FALSE [get_nets btnu_IBUF];
#set_property CLOCK_DEDICATED_ROUTE FALSE [get_nets btnd_IBUF];
#set_property CLOCK_DEDICATED_ROUTE FALSE [get_nets btnl_IBUF];
#set_property CLOCK_DEDICATED_ROUTE FALSE [get_nets btnr_IBUF];

set_property PACKAGE_PIN T18 [get_ports {btnu}]; #btnu
set_property PACKAGE_PIN R16 [get_ports {btnd}]; #btnd
set_property PACKAGE_PIN N15 [get_ports {btnl}]; #btnl
set_property PACKAGE_PIN R18 [get_ports {btnr}]; #btnr
set_property PACKAGE_PIN T22 [get_ports {led[0]}]; #led0
set_property PACKAGE_PIN T21 [get_ports {led[1]}]; #led1
set_property PACKAGE_PIN U22 [get_ports {led[2]}]; #led2
set_property PACKAGE_PIN U21 [get_ports {led[3]}]; #led3
set_property PACKAGE_PIN V22 [get_ports {led[4]}]; #led4
set_property PACKAGE_PIN W22 [get_ports {led[5]}]; #led5
set_property PACKAGE_PIN U19 [get_ports {led[6]}]; #led6
set_property PACKAGE_PIN U14 [get_ports {led[7]}]; #led7

set_property IOSTANDARD LVCMOS33 [get_ports btnu];
set_property IOSTANDARD LVCMOS33 [get_ports btnd];
set_property IOSTANDARD LVCMOS33 [get_ports btnl];
set_property IOSTANDARD LVCMOS33 [get_ports btnr];
set_property IOSTANDARD LVCMOS33 [get_ports led];


#set_property PACKAGE_PIN W8 [get_ports {sel}];
#set_property PACKAGE_PIN V10 [get_ports {ssd[0]}];
#set_property PACKAGE_PIN W11 [get_ports {ssd[1]}];
#set_property PACKAGE_PIN W12 [get_ports {ssd[2]}];
#set_property PACKAGE_PIN AA9 [get_ports {ssd[3]}];
#set_property PACKAGE_PIN Y10 [get_ports {ssd[4]}];
#set_property PACKAGE_PIN AA11 [get_ports {ssd[5]}];
#set_property PACKAGE_PIN Y11 [get_ports {ssd[6]}];

set_property PACKAGE_PIN V8 [get_ports {sel}];
set_property PACKAGE_PIN V9 [get_ports {ssd[0]}];
set_property PACKAGE_PIN W10 [get_ports {ssd[1]}];
set_property PACKAGE_PIN V12 [get_ports {ssd[2]}];
set_property PACKAGE_PIN AA8 [get_ports {ssd[3]}];
set_property PACKAGE_PIN AB9 [get_ports {ssd[4]}];
set_property PACKAGE_PIN AB10 [get_ports {ssd[5]}];
set_property PACKAGE_PIN AB11 [get_ports {ssd[6]}];

set_property IOSTANDARD LVCMOS33 [get_ports ssd];
set_property IOSTANDARD LVCMOS33 [get_ports sel];

set_property PACKAGE_PIN W8 [get_ports {pmodled[0]}];
set_property PACKAGE_PIN V10 [get_ports {pmodled[1]}];
set_property PACKAGE_PIN W11 [get_ports {pmodled[2]}];
set_property PACKAGE_PIN W12 [get_ports {pmodled[3]}];
set_property PACKAGE_PIN AA9 [get_ports {btn[3]}];
set_property PACKAGE_PIN Y10 [get_ports {btn[2]}];
set_property PACKAGE_PIN AA11 [get_ports {btn[1]}];
set_property PACKAGE_PIN Y11 [get_ports {btn[0]}];

set_property PACKAGE_PIN R6 [get_ports {pmodled[4]}];
set_property PACKAGE_PIN T6 [get_ports {pmodled[5]}];
set_property PACKAGE_PIN T4 [get_ports {pmodled[6]}];
set_property PACKAGE_PIN U4 [get_ports {pmodled[7]}];

set_property PACKAGE_PIN AB7 [get_ports {pmodled[8]}];
set_property PACKAGE_PIN AB6 [get_ports {pmodled[9]}];
set_property PACKAGE_PIN Y4 [get_ports {pmodled[10]}];
set_property PACKAGE_PIN AA4 [get_ports {pmodled[11]}];

set_property PACKAGE_PIN W7 [get_ports {pmodled[12]}];
set_property PACKAGE_PIN V7 [get_ports {pmodled[13]}];
set_property PACKAGE_PIN V4 [get_ports {pmodled[14]}];
set_property PACKAGE_PIN V5 [get_ports {pmodled[15]}];

set_property IOSTANDARD LVCMOS33 [get_ports pmodled];
set_property IOSTANDARD LVCMOS33 [get_ports btn];