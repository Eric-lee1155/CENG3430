-- Testbench automatically generated online
-- at https://vhdl.lapinoo.net
-- Generation date : 18.5.2023 06:59:59 UTC

library ieee;
use ieee.std_logic_1164.all;

entity tb_game is
end tb_game;

architecture tb of tb_game is

    component game
        port (btnu : in std_logic;
              btnd : in std_logic;
              btnl : in std_logic;
              btnr : in std_logic;
              led  : out std_logic_vector (7 downto 0);
              CLK  : in std_logic);
    end component;

    signal btnu : std_logic;
    signal btnd : std_logic;
    signal btnl : std_logic;
    signal btnr : std_logic;
    signal led  : std_logic_vector (7 downto 0);
    signal CLK  : std_logic;

begin

    dut : game
    port map (btnu => btnu,
              btnd => btnd,
              btnl => btnl,
              btnr => btnr,
              led  => led,
              CLK  => CLK);

    stimuli : process
    begin
        -- EDIT Adapt initialization as needed
        btnu <= '0';
        btnd <= '0';
        btnl <= '0';
        btnr <= '0';
        CLK <= '0';
        wait for 100ns;
        btnu <= '0';
        btnd <= '0';
        btnl <= '0';
        btnr <= '0';
        CLK <= '1';
        wait for 100ns;
        for i in 0 to 50000000 loop
        CLK <= NOT CLK;
        wait for 1ps;
        end loop
        -- EDIT Add stimuli here

        wait;
    end process;

end tb;

-- Configuration block below is required by some simulators. Usually no need to edit.

configuration cfg_tb_game of tb_game is
    for tb
    end for;
end cfg_tb_game;